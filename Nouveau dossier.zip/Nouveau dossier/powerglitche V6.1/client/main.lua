-- POWERGLITCHE V6 - client

local ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- STATE
local menuOpen, hudActive, cursorActive = false, false, false
local currentPage, selectedIndex = 1, 1
local cursorPos = nil
local cursorSize, powerStrength = 1.0, 1.0
local lastPos = nil
local continuousPower = nil
local laserActive = false
local animProgress = 0.0

-- CONTROLS
local CTRL_AIM    = 25
local CTRL_ENTER  = 176
local CTRL_UP     = 172
local CTRL_DOWN   = 173
local CTRL_LEFT   = 174
local CTRL_RIGHT  = 175
local CTRL_ESC    = 322
local CTRL_X      = 73
local CTRL_INSERT = 121

-- FX table
local FX_MAP = {
    teleport = {dict="core", name="exp_grd_grenade_smoke"},
    kamui = {dict="core", name="explosion_tofte"},
    heal = {dict="core", name="exp_grd_bomb"},
    explosion = {dict="exp_grd_bomb", name="exp_grd_bomb"},
    laser = {dict="core", name="ent_sht_elec_crackle"},
    lightning = {dict="scr_fbi4", name="scr_xm_orbital_emp"},
    phoenix = {dict="scr_rcbarry2", name="scr_xm_orbital_emp"},
    blackhole = {dict="scr_xm_orbital", name="scr_xm_orbital_emp"},
    earthquake = {dict="core", name="scr_xm_orbital_emp"},
    spirit = {dict="scr_xm_orbital", name="scr_xm_orbital_emp"}
}

-- 40 Powers (5 pages x 8)
local powers = {
    -- Page 1
    {page=1, name="Teleport", needCursor=true, fx="teleport", sound="whoosh"},
    {page=1, name="Kamui", needCursor=false, fx="kamui", sound="tx_god"},
    {page=1, name="Kamui Link", needCursor=true, fx="kamui", sound="tx_god"},
    {page=1, name="Godmode", needCursor=false, fx=nil, sound="SELECT"},
    {page=1, name="Heal", needCursor=false, fx="heal", sound="tx_heal"},
    {page=1, name="TBSYCLE", needCursor=false, fx="explosion", sound="EXPLOSION"},
    {page=1, name="Meteor Strike", needCursor=true, fx="explosion", sound="EXPLOSION"},
    {page=1, name="Black Hole", needCursor=true, fx="blackhole", sound="tx_blackhole"},

    -- Page 2
    {page=2, name="Ice Wall", needCursor=true, fx="teleport", sound="whoosh"},
    {page=2, name="Lightning Strike", needCursor=true, fx="lightning", sound="tx_lightning"},
    {page=2, name="Laser Eyes", needCursor=true, fx="laser", sound="tx_laser", continuous=true},
    {page=2, name="Shadow Clone", needCursor=false, fx=nil, sound="SELECT"},
    {page=2, name="Speed Burst", needCursor=false, fx=nil, sound="SELECT"},
    {page=2, name="Ultimate Heal", needCursor=false, fx="heal", sound="tx_heal"},
    {page=2, name="Spirit Bomb", needCursor=true, fx="spirit", sound="tx_spirit"},
    {page=2, name="Phoenix Mode", needCursor=false, fx="phoenix", sound="tx_flame"},

    -- Page 3
    {page=3, name="Demon Aura", needCursor=false, fx="kamui", sound="tx"},
    {page=3, name="Plasma Shot", needCursor=true, fx="laser", sound="tx"},
    {page=3, name="Earthquake", needCursor=true, fx="earthquake", sound="tx_earthquake"},
    {page=3, name="Ultimate Kamui", needCursor=false, fx="kamui", sound="tx_god"},
    {page=3, name="Element Fusion", needCursor=true, fx="spirit", sound="tx"},
    {page=3, name="Clone Army", needCursor=false, fx=nil, sound="SELECT"},
    {page=3, name="Energy Beam", needCursor=true, fx="laser", sound="tx"},
    {page=3, name="Meteor Rain", needCursor=true, fx="explosion", sound="EXPLOSION"},

    -- Page 4
    {page=4, name="Time Stop", needCursor=false, fx=nil, sound="SELECT"},
    {page=4, name="Tornado", needCursor=true, fx=nil, sound="tx"},
    {page=4, name="Ice Prison", needCursor=true, fx="teleport", sound="whoosh"},
    {page=4, name="Solar Flare", needCursor=true, fx="phoenix", sound="tx_flame"},
    {page=4, name="Shadow Step", needCursor=true, fx="teleport", sound="whoosh"},
    {page=4, name="Gravity Pull", needCursor=true, fx=nil, sound="tx"},
    {page=4, name="Explosion Field", needCursor=true, fx="explosion", sound="EXPLOSION"},
    {page=4, name="Aura Shield", needCursor=false, fx=nil, sound="SELECT"},

    -- Page 5
    {page=5, name="Death Beam", needCursor=true, fx="laser", sound="tx"},
    {page=5, name="Thunder Wave", needCursor=true, fx="lightning", sound="tx_lightning"},
    {page=5, name="Chrono Slash", needCursor=true, fx=nil, sound="tx"},
    {page=5, name="Flame Nova", needCursor=true, fx="phoenix", sound="tx_flame"},
    {page=5, name="Light Dash", needCursor=false, fx=nil, sound="SELECT"},
    {page=5, name="Absolute Zero", needCursor=true, fx="teleport", sound="whoosh"},
    {page=5, name="Dark Rift", needCursor=true, fx="blackhole", sound="tx_blackhole"},
    {page=5, name="World Reset", needCursor=true, fx="blackhole", sound="tx_blackhole"}
}

local function GetPowersByPage(page)
    local out = {}
    for _,p in ipairs(powers) do if p.page == page then table.insert(out, p) end end
    return out
end

-- UTILITIES
local function PlayEntitySound(soundName)
    if not soundName then return end
    local ped = PlayerPedId()
    PlaySoundFromEntity(-1, soundName, ped, "DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS", 0, 0, 0)
    TriggerServerEvent('powerglitche:playSoundGlobal', soundName, GetEntityCoords(ped))
end

local function RequestPtfx(dict)
    if not dict then return false end
    if HasNamedPtfxAssetLoaded(dict) then return true end
    RequestNamedPtfxAsset(dict)
    local t = GetGameTimer() + 1000
    while not HasNamedPtfxAssetLoaded(dict) and GetGameTimer() < t do Wait(10) end
    return HasNamedPtfxAssetLoaded(dict)
end

local function SpawnFx(id, coords, scale)
    if not id or not coords then return end
    local meta = FX_MAP[id] or FX_MAP["teleport"]
    if not meta then return end
    if RequestPtfx(meta.dict) then
        UseParticleFxAsset(meta.dict)
        StartParticleFxNonLoopedAtCoord(meta.name, coords.x, coords.y, coords.z, 0,0,0, scale or 1.0, false, false, false)
        TriggerServerEvent('powerglitche:triggerFXGlobal', {dict=meta.dict, name=meta.name, coords=coords, scale=scale})
    end
end

local function Notify(text)
    if ESX and ESX.ShowNotification then ESX.ShowNotification(text) else TriggerEvent('chat:addMessage', {args = {text}}) end
end

-- RAYCAST helpers
local function RotationToDirection(rotation)
    local z = math.rad(rotation.z)
    local x = math.rad(rotation.x)
    local cosX = math.cos(x)
    return vector3(-math.sin(z) * math.abs(cosX), math.cos(z) * math.abs(cosX), math.sin(x))
end

local function RaycastFromCamera(dist)
    local cam = GetGameplayCamCoord()
    local rot = GetGameplayCamRot(2)
    local dir = RotationToDirection(rot)
    local target = cam + dir * dist
    local ray = StartShapeTestRay(cam.x, cam.y, cam.z, target.x, target.y, target.z, -1, PlayerPedId(), 7)
    local _, hit, hitPos = GetShapeTestResult(ray)
    if hit == 1 then return true, hitPos end
    return false, target
end

-- DRAW helpers
local function DrawText(x,y,txt,scale,r,g,b,a,center)
    SetTextFont(0); SetTextProportional(1)
    SetTextScale(scale, scale)
    SetTextColour(r,g,b,a)
    SetTextOutline()
    if center then SetTextCentre(true) end
    BeginTextCommandDisplayText("STRING"); AddTextComponentString(txt); EndTextCommandDisplayText(x,y)
end

-- MENU / HUD
local function DrawMenu()
    if not menuOpen and animProgress <= 0 then return end
    local alpha = math.floor(220 * animProgress)
    local x,y,w,h = 0.10, 0.06, 0.30, 0.20
    DrawRect(x + 0.01, y + 0.07, w, h, 8,10,14, math.floor(170 * animProgress))
    DrawText(x, y, ("POWERGLITCHE V6  Page %d/5"):format(currentPage), 0.34, 200,200,255,alpha, false)
    local list = GetPowersByPage(currentPage)
    for i=1,#list do
        local py = y + 0.03 + i*0.02
        local sel = (i == selectedIndex)
        if sel then DrawRect(x+0.12, py, w*0.9, 0.018, 120,120,240, math.floor(90*animProgress)) end
        DrawText(x, py-0.006, string.format("%02d. %s", i, list[i].name), 0.28, 220,220,220,alpha, false)
    end
    DrawText(x, y + 0.18, "← → pages  |  ↑ ↓ power  |  ENTER select", 0.20, 180,180,180,alpha, false)
end

local function DrawHUD()
    if not hudActive then return end
    local x,y = 0.12, 0.03
    DrawRect(x+0.08, y+0.03, 0.26, 0.06, 8,8,12,190)
    local p = GetPowersByPage(currentPage)[selectedIndex]
    DrawText(x, y, ("Pouvoir: %s"):format(p and p.name or "—"), 0.34, 200,200,255,255, false)
    DrawText(x, y+0.028, ("[Clic droit] Activer  |  [↑↓] Puissance: %.1f"):format(powerStrength), 0.20, 180,180,180,220, false)
    local barX, barY = x+0.19, y+0.04
    local pct = math.min(1, (powerStrength-0.5)/2.5)
    DrawRect(barX - 0.06, barY, 0.12, 0.01, 40,40,60,200)
    DrawRect(barX - 0.06 + (0.12 * (pct-1)/2), barY, 0.12 * pct, 0.01, 120,200,255,220)
end

-- CURSOR
local function UpdateCursor()
    if not cursorActive then return end
    local hit, pos = RaycastFromCamera(800.0)
    cursorPos = pos
    if cursorPos then
        local size = 0.6 * cursorSize
        DrawMarker(28, cursorPos.x, cursorPos.y, cursorPos.z + 0.5, 0,0,0, 0,0,0, size, size, size, 255, 60, 60, 180, false, true, 2, false, nil, nil, false)
        if math.random() < 0.02 then SpawnFx("teleport", cursorPos, 0.5 * cursorSize) end
    end
end

-- ACTIVATE power (implementations kept safe & optimized)
local function ActivatePower(p)
    local ped = PlayerPedId()
    local pos = cursorPos or GetEntityCoords(ped)
    lastPos = GetEntityCoords(ped)

    if p.fx then SpawnFx(p.fx, pos, math.max(0.6, cursorSize)) end
    if p.sound then PlayEntitySound(p.sound) end

    if p.name == "Teleport" and cursorPos then
        SetEntityCoords(ped, pos.x, pos.y, pos.z + 1.0, false, false, false, false)
        SpawnFx("teleport", pos, cursorSize)
        Notify("Téléportation effectuée")
    elseif p.name == "Heal" then
        SetEntityHealth(ped, GetEntityMaxHealth(ped))
        SetPedArmour(ped, 100)
        SpawnFx("heal", GetEntityCoords(ped), 1.0)
        Notify("Soins appliqués")
    elseif p.name == "Godmode" then
        SetEntityInvincible(ped, true)
        Notify("Godmode ON (10s)")
        Citizen.SetTimeout(10000, function() SetEntityInvincible(ped, false); Notify("Godmode OFF") end)
    elseif p.name == "Meteor Strike" or p.name == "Meteor Rain" then
        if cursorPos then
            for i=1,5 do
                AddExplosion(pos.x + math.random(-8,8), pos.y + math.random(-8,8), pos.z + 30.0, 7, 8.0 * powerStrength, true, false, 1.0)
                Wait(150)
            end
            Notify("Meteor impact")
        end
    elseif p.name == "Laser Eyes" and cursorPos then
        laserActive = true; continuousPower = "laser"
        Notify("Laser actif (maintenir visée, X stop)")
        Citizen.CreateThread(function()
            while laserActive and continuousPower == "laser" do
                if cursorPos then
                    local ppos = GetEntityCoords(ped)
                    DrawLine(ppos.x, ppos.y, ppos.z+0.6, cursorPos.x, cursorPos.y, cursorPos.z, 255,0,0,255)
                    AddExplosion(cursorPos.x, cursorPos.y, cursorPos.z, 5, 1.0 * powerStrength, true, false, 0.1)
                end
                Wait(80)
            end
        end)
    elseif p.name == "Shadow Clone" then
        local model = GetHashKey("a_m_m_skater_01")
        RequestModel(model); while not HasModelLoaded(model) do Wait(10) end
        local posc = GetEntityCoords(ped) + GetEntityForwardVector(ped) * 1.2
        local clone = CreatePed(4, model, posc.x, posc.y, posc.z, GetEntityHeading(ped), true, false)
        SetEntityAsMissionEntity(clone, true, false)
        Notify("Clone créé")
        Citizen.SetTimeout(15000, function() if DoesEntityExist(clone) then DeleteEntity(clone) end end)
    elseif p.name == "Black Hole" and cursorPos then
        SpawnFx("blackhole", pos, 2.2)
        PlayEntitySound("tx_blackhole")
        Notify("Black Hole déclenché")
    elseif p.name == "Earthquake" and cursorPos then
        ShakeGameplayCam("SMALL_EXPLOSION_SHAKE", 1.0 * powerStrength)
        Notify("Séisme")
    elseif p.name == "World Reset" and cursorPos then
        SpawnFx("blackhole", pos, 2.5)
        PlayEntitySound("tx_blackhole")
        for i=1,6 do
            AddExplosion(pos.x + math.random(-20,20), pos.y + math.random(-20,20), pos.z, 7, 6.0 * powerStrength, true, false, 0.5)
            Wait(200)
        end
        Notify("World Reset exécuté")
    else
        -- Generic fallback for other powers: small FX + feedback
        SpawnFx(p.fx or "teleport", pos, 0.8)
        PlayEntitySound(p.sound or "SELECT")
        Notify(("Pouvoir %s activé"):format(p.name))
    end

    -- cleanup UI
    hudActive = false
    cursorActive = false
    menuOpen = false
end

-- MAIN THREAD (optimized)
Citizen.CreateThread(function()
    local sleep = 250
    while true do
        if menuOpen or hudActive or cursorActive or laserActive or continuousPower then sleep = 0 else sleep = 250 end
        Wait(sleep)

        -- toggle via INSERT (local)
        if IsControlJustReleased(0, CTRL_INSERT) then
            menuOpen = not menuOpen
            hudActive = false
            cursorActive = false
            animProgress = menuOpen and 1.0 or 0.0
            PlayEntitySound("SELECT")
            if menuOpen then Notify("POWERGLITCHE V6 - Menu ouvert") end
        end

        -- draw when needed
        if menuOpen or hudActive or cursorActive then
            if menuOpen then animProgress = math.min(1.0, animProgress + 0.06) else animProgress = math.max(0.0, animProgress - 0.06) end
            DrawMenu()
            DrawHUD()
            UpdateCursor()
        end

        -- Menu navigation
        if menuOpen then
            if IsControlJustReleased(0, CTRL_LEFT) then currentPage = (currentPage - 2) % 5 + 1; selectedIndex = 1; PlayEntitySound("SELECT") end
            if IsControlJustReleased(0, CTRL_RIGHT) then currentPage = currentPage % 5 + 1; selectedIndex = 1; PlayEntitySound("SELECT") end
            if IsControlJustReleased(0, CTRL_UP) then selectedIndex = math.max(1, selectedIndex - 1); PlayEntitySound("SELECT") end
            if IsControlJustReleased(0, CTRL_DOWN) then selectedIndex = selectedIndex + 1; local list = GetPowersByPage(currentPage); if selectedIndex > #list then selectedIndex = 1 end; PlayEntitySound("SELECT") end
            if IsControlJustReleased(0, CTRL_ENTER) then
                menuOpen = false; hudActive = true
                local p = GetPowersByPage(currentPage)[selectedIndex]
                if p and p.needCursor then cursorActive = true end
                PlayEntitySound("SELECT")
            end
            if IsControlJustReleased(0, CTRL_ESC) then menuOpen = false; PlayEntitySound("CANCEL"); Notify("Menu fermé") end
        end

        -- HUD controls
        if hudActive then
            if IsControlJustReleased(0, CTRL_UP) then powerStrength = math.min(4.0, powerStrength + 0.1); cursorSize = math.min(3.0, cursorSize + 0.05); PlayEntitySound("SELECT") end
            if IsControlJustReleased(0, CTRL_DOWN) then powerStrength = math.max(0.5, powerStrength - 0.1); cursorSize = math.max(0.4, cursorSize - 0.05); PlayEntitySound("SELECT") end
            if IsControlJustReleased(0, CTRL_ESC) then hudActive=false; cursorActive=false; continuousPower=nil; laserActive=false; PlayEntitySound("CANCEL"); Notify("Mode pouvoir quitté") end
            if IsControlJustReleased(0, CTRL_AIM) then
                local p = GetPowersByPage(currentPage)[selectedIndex]
                if p then
                    if p.needCursor and not cursorPos then Notify("Placez le curseur (regard)") else ActivatePower(p) end
                end
            end
            if IsControlJustReleased(0, CTRL_X) then laserActive=false; continuousPower=nil; Notify("Pouvoirs continus stoppés"); PlayEntitySound("CANCEL") end
        end

        -- cursor tuning
        if cursorActive then
            if IsControlJustReleased(0, CTRL_UP) then cursorSize = math.min(3.0, cursorSize + 0.05) end
            if IsControlJustReleased(0, CTRL_DOWN) then cursorSize = math.max(0.4, cursorSize - 0.05) end
        end

        -- stop continuous laser if not aiming
        if laserActive and not IsControlPressed(0, CTRL_AIM) then
            laserActive = false
            Notify("Laser stoppé")
        end
    end
end)

-- NETWORK EVENTS
RegisterNetEvent('powerglitche:openMenu')
AddEventHandler('powerglitche:openMenu', function()
    menuOpen = true; hudActive = false; cursorActive = false; animProgress = 1.0
    Notify("POWERGLITCHE V6 - Menu ouvert")
    PlayEntitySound("SELECT")
end)

RegisterNetEvent('powerglitche:playSoundClient')
AddEventHandler('powerglitche:playSoundClient', function(soundName, coords)
    if not soundName then return end
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    if not coords or #(pos - coords) < 200.0 then
        PlaySoundFromEntity(-1, soundName, ped, "DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS", 0, 0, 0)
    end
end)

RegisterNetEvent('powerglitche:triggerFXClient')
AddEventHandler('powerglitche:triggerFXClient', function(fxData)
    if not fxData or not fxData.coords then return end
    if RequestPtfx(fxData.dict) then
        UseParticleFxAsset(fxData.dict)
        StartParticleFxNonLoopedAtCoord(fxData.name, fxData.coords.x, fxData.coords.y, fxData.coords.z, 0,0,0, fxData.scale or 1.0, false, false, false)
    end
end)

-- Local command for convenience (client-side)
RegisterCommand('powerglitche', function()
    TriggerEvent('powerglitche:openMenu')
end, false)

-- Chat suggestion
TriggerEvent('chat:addSuggestion', '/powerglitche', 'Ouvre le menu POWERGLITCHE V6')

print("[POWERGLITCHE V6] Client loaded")