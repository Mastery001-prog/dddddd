fx_version 'cerulean'
game 'gta5'

author 'Glitche'
description 'POWERGLITCHE V6 – Ultimate RP Powers System'
version '6.0.0'

dependencies {
    'es_extended',
    'RageUI',
    'ox_lib'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

lua54 'yes'

shared_scripts {
    'locales/core.js'
}
