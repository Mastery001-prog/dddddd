-- POWERGLITCHE V6 - server
local ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

print("[POWERGLITCHE V6] Server started")

-- Command to open menu for the player who uses it
RegisterCommand('powerglitche', function(source, args, raw)
    if source == 0 then
        print("[POWERGLITCHE V6] /powerglitche used from console")
        return
    end
    TriggerClientEvent('powerglitche:openMenu', source)
end, false)

-- Broadcast a sound to clients (server-side sync helper)
RegisterNetEvent('powerglitche:playSoundGlobal')
AddEventHandler('powerglitche:playSoundGlobal', function(soundName, coords)
    TriggerClientEvent('powerglitche:playSoundClient', -1, soundName, coords)
end)

-- Broadcast FX to clients
RegisterNetEvent('powerglitche:triggerFXGlobal')
AddEventHandler('powerglitche:triggerFXGlobal', function(fxData)
    TriggerClientEvent('powerglitche:triggerFXClient', -1, fxData)
end)

print("[POWERGLITCHE V6] Events registered: powerglitche:playSoundGlobal, powerglitche:triggerFXGlobal")